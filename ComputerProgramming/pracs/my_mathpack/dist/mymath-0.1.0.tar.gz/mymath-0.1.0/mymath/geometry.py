from math import pi, pow

def circle_area(radius):
    return pi * pow(radius, 2)