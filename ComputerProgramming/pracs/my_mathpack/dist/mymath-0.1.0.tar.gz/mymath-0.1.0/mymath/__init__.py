from .algebra import solve_quadratic
from .geometry import circle_area
from .utils import random_quadratic